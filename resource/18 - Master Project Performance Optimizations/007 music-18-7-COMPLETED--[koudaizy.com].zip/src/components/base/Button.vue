<template>
  <button type="button">Press Me!</button>
</template>
